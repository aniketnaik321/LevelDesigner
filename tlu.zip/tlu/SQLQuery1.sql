USE [CAPFIRST_ONLINE_TLU]
GO
/****** Object:  Table [dbo].[AccountContacts]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AccountContacts](
	[CONTACTID] [bigint] NULL,
	[ACCOUNTID] [bigint] NULL,
	[CONTACTTYPEID] [bigint] NULL,
	[ISSENSITIVE] [nchar](1) NULL,
	[VALIDFROM] [datetime] NULL,
	[VALIDTO] [datetime] NULL,
	[CREATED] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[audit_log]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[audit_log](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[file_name] [varchar](250) NULL,
	[path] [varchar](250) NULL,
	[start_ts] [datetime] NULL,
	[end_ts] [datetime] NULL,
	[rec_total] [bigint] NULL,
	[rec_rej] [bigint] NULL,
	[rec_vld] [bigint] NULL,
	[rej_filepath] [varchar](250) NULL,
	[archived_path] [varchar](250) NULL,
	[lst_upd_on] [datetime] NULL,
	[lst_upd_by] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CFL_CC_ACCOUNTDETAILS]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CFL_CC_ACCOUNTDETAILS](
	[ACCOUNT_NUMBER] [nvarchar](25) NOT NULL,
	[PRIMARY_CARD_NUMBER] [nvarchar](25) NULL,
	[NEW_CASE_ADDED] [nvarchar](1) NULL,
	[PRIME_ACCOUNT_DEL_STATUS] [nvarchar](1) NULL,
	[PRIME_CASE_TYPE] [nvarchar](5) NULL,
	[PRIME_ACCOUNT_GENERAL_STATUS] [nvarchar](4) NULL,
	[PRIME_COLLECTION_CREATION_DATE] [datetime] NULL,
	[PRIME_COLLECTIONS_EXITED_DATE] [datetime] NULL,
	[LOGO] [nvarchar](30) NULL,
	[LOGO_DESCRIPTION] [nvarchar](255) NULL,
	[CARD_OPEN_DATE] [datetime] NULL,
	[CARD_BLOCKED_STATUS] [nvarchar](1) NULL,
	[CREDIT_LIMIT] [numeric](16, 3) NULL,
	[CASH_LIMIT] [numeric](16, 3) NULL,
	[AD_MANDATE_SB_ACC_NUMBER] [nvarchar](50) NULL,
	[AD_MANDATE_ACCOUNT_TYPE] [nvarchar](5) NULL,
	[LAST_STATEMENT_DATE] [datetime] NULL,
	[STATEMENTED_OPENING_BALANCE] [numeric](16, 3) NULL,
	[STMT_CLOSE_BAL_PYMT_CYC_DUE] [numeric](16, 3) NULL,
	[CURRENT_MINIMUM_AMOUNT_DUE] [numeric](16, 3) NULL,
	[STATEMENTED_BLOCK_CODE] [nvarchar](4) NULL,
	[STATEMENTED_DUE_DATE_PRINTED] [datetime] NULL,
	[STATEMENTED_DUE_DATE_SYSTEM] [datetime] NULL,
	[CURRENT_BALANCE_AMOUNT] [numeric](16, 3) NULL,
	[CURRENT_TOTAL_AMOUNT_DUE] [numeric](16, 3) NULL,
	[PRIME_OVERLIMIT_AMOUNT] [numeric](16, 3) NULL,
	[DPD_EXTRACTION_DATE] [datetime] NULL,
	[CURRENT_BLOCK_CODE] [nvarchar](4) NULL,
	[CURRENT_BLOCK_CODE_DATE] [datetime] NULL,
	[PAST_DAYS_PAYMENT_DUE] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_30] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_60] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_90] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_120] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_150] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_180] [numeric](16, 3) NULL,
	[DAYS_PAYMENT_DUE_210] [numeric](16, 3) NULL,
	[TOTAL_PURCHASES] [numeric](16, 3) NULL,
	[LAST_PAYMENT_AMOUNT] [numeric](16, 3) NULL,
	[LAST_PAYMENT_POSTING_DATE] [datetime] NULL,
	[LAST_PAYMENT_VALUE_DATE] [datetime] NULL,
	[LAST_PAYMENT_REMARK] [nvarchar](254) NULL,
	[LAST_PAYMENT_MODE] [nvarchar](254) NULL,
	[LAST_PAYMENT_REFERENCE_NUMBER] [nvarchar](254) NULL,
	[LAST_PURCHASED_AMOUNT] [numeric](16, 3) NULL,
	[LAST_PURCHASED_DATE] [datetime] NULL,
	[LAST_PURCHASED_TRANSACTION_REM] [nvarchar](254) NULL,
	[LAST_CHEQUE_BOUNCE_AMOUNT] [numeric](16, 3) NULL,
	[LAST_CHEQUE_BOUNCE_DATE] [datetime] NULL,
	[LAST_CHEQUE_BOUNCE_REASON] [nvarchar](254) NULL,
	[LAST_CHEQUE_BOUNCE_NUMBER] [nvarchar](254) NULL,
	[LAST_CHEQUE_ISSUANCE_BANK_NAME] [nvarchar](100) NULL,
	[EMI_AMOUNT] [numeric](16, 3) NULL,
	[EMI_OUTSTANDING] [numeric](16, 3) NULL,
	[PRINCIPAL_BALANCE] [numeric](16, 3) NULL,
	[INTEREST] [numeric](16, 3) NULL,
	[FEES] [numeric](16, 3) NULL,
	[DELINQUENCY_STRING] [nvarchar](12) NULL,
	[WRITE_OFF_AMOUNT] [numeric](16, 3) NULL,
	[WRITE_OFF_DATE] [datetime] NULL,
	[ADD_ON_CARD_NUMBER] [nvarchar](25) NULL,
	[ADD_ON_CRD_HOLDER_REL_WTH_CUST] [nvarchar](5) NULL,
	[ACCOUNTS1] [int] NOT NULL,
	[PRIME_CASE_TYPE_SEVERITY] [int] NULL,
	[PRIME_ACCOUNT_OWNER_TYPE] [int] NULL,
	[BILLING_CYCLE] [int] NULL,
	[STATEMENTED_DPD] [int] NULL,
	[STATEMENTED_BUCKET] [int] NULL,
	[CURRENT_DPD] [int] NULL,
	[CURRENT_BUCKET] [int] NULL,
	[CURRENT_DAYS_PAYMENT_DUE] [numeric](16, 3) NULL,
 CONSTRAINT [PK_CFL_CC_ACCOUNTDETAILS] PRIMARY KEY CLUSTERED 
(
	[ACCOUNT_NUMBER] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CFL_CC_CUSTOMERDETAILS]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CFL_CC_CUSTOMERDETAILS](
	[CUSTOMER_IDENTIFICATION_NUMBER] [nvarchar](30) NOT NULL,
	[CUSTOMER_NAME] [nvarchar](101) NULL,
	[CUSTOMER_DOB] [datetime] NULL,
	[CUSTOMER_SALUTATION] [nvarchar](20) NULL,
	[GENDER] [nvarchar](1) NULL,
	[MARITAL_STATUS] [nvarchar](1) NULL,
	[NATIONALITY] [nvarchar](255) NULL,
	[PROFESSION_CUSTOMER_TYPE] [nvarchar](255) NULL,
	[CUSTOMER_CITY_BRANCH_CODE] [nvarchar](5) NULL,
	[CUSTOMER_PASSPORT_NUMBER] [nvarchar](255) NULL,
	[CUSTOMER_PAN_NUMBER] [nvarchar](255) NULL,
	[CUSTOMER_DRIVING_LICENSE_NUM] [nvarchar](255) NULL,
	[CUSTOMER_VOTER_ID_NUMBER] [nvarchar](255) NULL,
	[CUSTOMER_AADHAAR_NUMBER] [nvarchar](255) NULL,
	[CUSTOMER_EMPLOYER_OFFICE_NAME] [nvarchar](30) NULL,
	[OFFICE_DESIGNATION] [nvarchar](30) NULL,
	[ADD_ON_FIRST_NAME] [nvarchar](50) NULL,
	[ADD_ON_LAST_NAME] [nvarchar](50) NULL,
	[ADD_ON_ADDRESS_TYPE] [nvarchar](50) NULL,
	[ADD_ON_PASSPORT] [nvarchar](255) NULL,
	[ADD_ON_PAN_NO] [nvarchar](255) NULL,
	[ADD_ON_DRIVING_LICENSE_NO] [nvarchar](255) NULL,
	[ADD_ON_VOTER_ID_CARD] [nvarchar](255) NULL,
	[ADD_ON_DESIGNATION] [nvarchar](30) NULL,
	[ADD_ON_AADHAAR_CARD_NO] [nvarchar](255) NULL,
	[CUSTOMERS1] [int] NOT NULL,
	[CUSTOMER_CITY_BRANCH_CODE_DESC] [nvarchar](40) NULL,
 CONSTRAINT [PK_CFL_CC_CUSTOMERDETAILS] PRIMARY KEY CLUSTERED 
(
	[CUSTOMER_IDENTIFICATION_NUMBER] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CONTACTADDRESSES]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CONTACTADDRESSES](
	[ID] [int] NOT NULL,
	[CONTACTID] [int] NULL,
	[ADDRESS1] [nvarchar](200) NULL,
	[ADDRESS2] [nvarchar](200) NULL,
	[ADDRESS3] [nvarchar](200) NULL,
	[ADDRESS4] [nvarchar](200) NULL,
	[ADDRESS5] [nvarchar](200) NULL,
	[ADDRESS6] [nvarchar](200) NULL,
	[ADDRESS7] [nvarchar](200) NULL,
	[ADDRESS8] [nvarchar](200) NULL,
	[ADDRESS9] [nvarchar](200) NULL,
	[ADDRESS10] [nvarchar](200) NULL,
	[ADDRESS11] [nvarchar](200) NULL,
	[ADDRESS12] [nvarchar](200) NULL,
	[ADDRESS13] [nvarchar](200) NULL,
	[ADDRESS14] [nvarchar](200) NULL,
	[POSTALCODE] [nvarchar](20) NULL,
	[COUNTRYCODE] [nvarchar](2) NULL,
	[ISMAILING] [nvarchar](1) NULL,
	[ISPROVISIONAL] [nvarchar](1) NULL,
	[ADDRESSTYPEID] [int] NULL,
	[UUID] [nvarchar](36) NULL,
	[EXTERNALREF] [nvarchar](36) NULL,
	[VALIDFROM] [datetime] NULL,
	[VALIDTO] [datetime] NULL,
	[CUSTOMFIELD01] [nvarchar](100) NULL,
	[CUSTOMFIELD02] [nvarchar](100) NULL,
	[CUSTOMFIELD03] [nvarchar](100) NULL,
	[CUSTOMFIELD04] [nvarchar](100) NULL,
	[CUSTOMFIELD05] [nvarchar](100) NULL,
	[CUSTOMFIELD06] [nvarchar](100) NULL,
	[CUSTOMFIELD07] [nvarchar](100) NULL,
	[CUSTOMFIELD08] [nvarchar](100) NULL,
	[CUSTOMFIELD09] [nvarchar](100) NULL,
	[CUSTOMFIELD10] [nvarchar](100) NULL,
	[PREVIOUSSTATE] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CONTACTEMAILS]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CONTACTEMAILS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CONTACTID] [int] NULL,
	[DESCRIPTION] [nvarchar](200) NULL,
	[EMAILADDRESS] [nvarchar](200) NULL,
	[ISPREFERRED] [nvarchar](1) NULL,
	[ISPROVISIONAL] [nvarchar](1) NULL,
	[UUID] [nvarchar](36) NULL,
	[EXTERNALREF] [nvarchar](36) NULL,
	[VALIDFROM] [datetime] NULL,
	[VALIDTO] [datetime] NULL,
	[CUSTOMFIELD01] [nvarchar](100) NULL,
	[CUSTOMFIELD02] [nvarchar](100) NULL,
	[CUSTOMFIELD03] [nvarchar](100) NULL,
	[CUSTOMFIELD04] [nvarchar](100) NULL,
	[CUSTOMFIELD05] [nvarchar](100) NULL,
	[CUSTOMFIELD06] [nvarchar](100) NULL,
	[CUSTOMFIELD07] [nvarchar](100) NULL,
	[CUSTOMFIELD08] [nvarchar](100) NULL,
	[CUSTOMFIELD09] [nvarchar](100) NULL,
	[CUSTOMFIELD10] [nvarchar](100) NULL,
	[PREVIOUSSTATE] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CONTACTPHONES]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CONTACTPHONES](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CONTACTID] [int] NULL,
	[PHONENUMBER] [nvarchar](20) NULL,
	[PHONETYPEID] [int] NULL,
	[ISPREFERRED] [nvarchar](1) NULL,
	[ISPROVISIONAL] [nvarchar](1) NULL,
	[UUID] [nvarchar](36) NULL,
	[EXTERNALREF] [nvarchar](36) NULL,
	[VALIDFROM] [datetime] NULL,
	[VALIDTO] [datetime] NULL,
	[CUSTOMFIELD01] [nvarchar](100) NULL,
	[CUSTOMFIELD02] [nvarchar](100) NULL,
	[CUSTOMFIELD03] [nvarchar](100) NULL,
	[CUSTOMFIELD04] [nvarchar](100) NULL,
	[CUSTOMFIELD05] [nvarchar](100) NULL,
	[CUSTOMFIELD06] [nvarchar](100) NULL,
	[CUSTOMFIELD07] [nvarchar](100) NULL,
	[CUSTOMFIELD08] [nvarchar](100) NULL,
	[CUSTOMFIELD09] [nvarchar](100) NULL,
	[CUSTOMFIELD10] [nvarchar](100) NULL,
	[PREVIOUSSTATE] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CONTACTS]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CONTACTS](
	[ID] [bigint] NOT NULL,
	[CONTACTREF] [varchar](50) NULL,
	[TITLE] [varchar](50) NULL,
	[GIVENNAME] [varchar](80) NULL,
	[FAMILYNAME] [varchar](80) NULL,
	[MIDDLENAME] [varchar](50) NULL,
	[COMPANYNAME] [varchar](50) NULL,
 CONSTRAINT [PK_CONTACTS] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CONTACTTYPES]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CONTACTTYPES](
	[ID] [int] NOT NULL,
	[NAME] [nvarchar](200) NOT NULL,
	[ISDELETED] [nvarchar](1) NOT NULL,
	[RELATESTO] [nvarchar](1) NOT NULL,
	[CARDINALITY] [nvarchar](1) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InterfaceLogs]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InterfaceLogs](
	[INTERFACEFILEID] [int] NOT NULL,
	[INTERFACEID] [varchar](50) NULL,
	[DATETIME] [varchar](50) NULL,
	[PRIORITY] [varchar](50) NULL,
	[REDCORD] [varchar](2000) NULL,
	[STATUS] [varchar](50) NULL,
	[DESCRIPTION] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InterfaceRecords]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InterfaceRecords](
	[INTERFACEFILEID] [int] NOT NULL,
	[INTERFACEID] [varchar](50) NULL,
	[DATETIME] [varchar](50) NULL,
	[PRIORITY] [varchar](50) NULL,
	[REDCORD] [varchar](2000) NULL,
	[STATUS] [varchar](50) NULL,
	[DESCRIPTION] [varchar](50) NULL,
	[MD5HASH] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[INTERFACES]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[INTERFACES](
	[ID] [int] NOT NULL,
	[NAME] [nvarchar](60) NULL,
	[CUSTOMERKEY] [nvarchar](30) NULL,
	[ACCOUNTKEY] [nvarchar](30) NULL,
	[BALANCEKEY] [nvarchar](30) NULL,
	[SERVICEKEY] [nvarchar](30) NULL,
	[PRODUCTKEY] [nvarchar](30) NULL,
	[CONTACTSKEY] [nvarchar](30) NULL,
	[TRANSACTIONKEY] [nvarchar](30) NULL,
	[LOCALKEY] [nvarchar](30) NULL,
	[TYPE] [numeric](1, 0) NULL,
	[EVENTID] [int] NULL,
	[DELIMITER] [nvarchar](1) NOT NULL,
	[RECORDTYPE] [nvarchar](1) NULL,
	[LOGSTATUS] [nvarchar](1) NOT NULL,
	[ACCOUNTSTATUS] [numeric](1, 0) NULL,
	[DESCRIPTION] [nvarchar](512) NULL,
	[EAINAME] [nvarchar](256) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[run_log]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[run_log](
	[run_id] [bigint] IDENTITY(1,1) NOT NULL,
	[run_name] [varchar](50) NULL,
	[submitted_on] [datetime] NULL,
	[script_file_path] [varchar](50) NULL,
	[format_file_name] [varchar](50) NULL,
	[run_status] [varchar](50) NULL,
 CONSTRAINT [PK_run_log] PRIMARY KEY CLUSTERED 
(
	[run_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INTERFACES] ADD  DEFAULT ('Y') FOR [LOGSTATUS]
GO
/****** Object:  StoredProcedure [dbo].[GET_AUTO_KEYS]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[GET_AUTO_KEYS] 
	@ACCOUNTS1 BIGINT OUT,
	@CUSTOMERS1 BIGINT OUT,
	@CONTACT_DETAILS_ID BIGINT OUT,
	@CONTACT_ADDRESS_ID BIGINT OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET @ACCOUNTS1=(SELECT ISNULL(MAX(ACCOUNTS1),1) FROM [dbo].[CFL_CC_ACCOUNTDETAILS])

	SET @CUSTOMERS1=(SELECT ISNULL(MAX(@CUSTOMERS1),1) FROM [dbo].[CFL_CC_CUSTOMERDETAILS])

	SET  @CONTACT_DETAILS_ID=(SELECT ISNULL(MAX(ID),1) FROM [dbo].[CONTACTS]);
	SET  @CONTACT_ADDRESS_ID=(SELECT ISNULL(MAX(ID),1) FROM [dbo].[CONTACTADDRESSES]);
   
END
GO
/****** Object:  StoredProcedure [dbo].[GetNextInterfaceFileID]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[GetNextInterfaceFileID](
@result int OUT

)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET @result=(SELECT ISNULL(MAX(INTERFACEFILEID)+1,1135) FROM InterfaceLogs);


	
END
GO
/****** Object:  StoredProcedure [dbo].[UPDATE_INTERFACE_TABLE]    Script Date: 8/19/2020 4:50:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[UPDATE_INTERFACE_TABLE] 	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

INSERT INTO INTERFACES
                         (ID, NAME, TYPE, DELIMITER, LOGSTATUS)
VALUES        (18, N'Contact_CC_Addresses', 5, N'|', N'Y')

INSERT INTO INTERFACES
                         (ID, NAME, TYPE, DELIMITER, LOGSTATUS)
VALUES        (19, N'Contact_CC_Phones', 5, N'|', N'Y')

INSERT INTO INTERFACES
                         (ID, NAME, TYPE, DELIMITER, LOGSTATUS)
VALUES        (20, N'Contact CC Email', 5, N'|', N'Y')


INSERT INTO INTERFACES
                         (ID, NAME, TYPE, DELIMITER, LOGSTATUS, DESCRIPTION, EAINAME, RECORDTYPE, ACCOUNTSTATUS)
VALUES        (22, N'CCCustomer', 2, N'|', N'Y', N'N', N'N', N'N', 0)


INSERT INTO INTERFACES
                         (ID, NAME, TYPE, DELIMITER, LOGSTATUS, DESCRIPTION, EAINAME, RECORDTYPE, ACCOUNTSTATUS)
VALUES        (22, N'CCAccount', 2, N'|', N'Y', N'N', N'N', N'N', 0)
	
END
GO
