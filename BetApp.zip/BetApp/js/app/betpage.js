$(function(){

$(".challenger").click(function(){
$("#betAmountModal").modal("show");
});

});